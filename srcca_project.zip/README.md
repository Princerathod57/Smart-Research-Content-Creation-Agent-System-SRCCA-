
# Smart Research & Content Creator Agent System (SRCCA)

**Track:** Concierge Agents  
**Title:** Smart Research & Content Creator Agent System (SRCCA)  
**Subtitle:** An AI agent system that automates research, writing, summarization, and SEO tuning.

## Project Overview
SRCCA is a multi-agent system designed to automate the multi-step content creation workflow: research, summarization, drafting, SEO optimization, and review. The system demonstrates agent orchestration, memory, tool integration, and observability.

## Features
- Multi-agent orchestration (Supervisor, Research, Summarizer, Writer, SEO, Review)
- Parallel research agents and sequential drafting flow
- Tools: Google Search connector, custom summarizer, code execution for data tasks
- Sessions & MemoryBank for user preferences
- Observability: structured logs, trace IDs, metrics
- Evaluation: readability, SEO scoring, plagiarism/similarity checks
- Demo notebook included (main.ipynb)

## File structure
```
project/
│── src/
│   │── supervisor_agent.py  (stub)
│   │── research_agent.py    (stub)
│   │── writer_agent.py      (stub)
│   │── seo_agent.py         (stub)
│   │── review_agent.py      (stub)
│   │── tools/
│       │── google_search_tool.py (stub)
│       │── summarizer_tool.py   (stub)
│
│── main.ipynb
│── README.md
│── KAGGLE_SUBMISSION.md
│── demo_video_script.txt
```

## How to use
1. Open `main.ipynb` (Kaggle Notebook friendly) to view the demo and run sample cells.
2. Add your API keys as environment variables (do NOT commit API keys to repo).
3. Follow the README and Kaggle submission guide for packaging the project.

## Notes for graders
- Contains detailed writeup, architecture, and demo steps.
- Demonstrates at least three required concepts (multi-agent, tools, sessions & memory).
- No API keys included.

---
